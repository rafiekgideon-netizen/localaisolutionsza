import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import { blueprintText } from "./serverBlueprint.js";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Use JSON middleware for API parsing
  app.use(express.json());

  // Initialize Gemini API
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "dummy" });

  app.post("/api/chat", async (req, res) => {
    try {
      const { messages } = req.body;
      
      const systemInstruction = `You are an AI assistant for Local AI Solutions (LAIS), a Cape Town-based AI automation agency. 
You must act as an expert on their master blueprint context. Your goal is to help visitors understand how LAIS can recover their revenue through 24/7 lead capture and automation.
Be direct, tactile, confident, local, practical, and not hype. Answer visitors' questions in short, concise responses. Use South African context when appropriate.
Here is the LAIS blueprint knowledge base:\n${blueprintText}`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: messages,
        config: {
          systemInstruction,
          temperature: 0.7,
        }
      });

      res.json({ text: response.text });
    } catch (error: any) {
      console.error("Gemini API Error:", error);
      res.status(500).json({ error: "An error occurred responding to your query." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(process.cwd(), "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(process.cwd(), "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
