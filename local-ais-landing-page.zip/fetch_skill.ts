import fs from 'fs';

async function main() {
  const res = await fetch('https://raw.githubusercontent.com/pbakaus/impeccable/main/.gemini/skills/impeccable/SKILL.md');
  const text = await res.text();
  console.log(text);
  fs.writeFileSync('impeccable_skill.md', text);
}

main();
